package com.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.dao.StudentDao;
import com.student.entity.Student;
@Service
public class StudentService {

	 @Autowired
	   StudentDao dao;
	public List<Student> getstudentRecord() {
		List<Student> list=dao.getstudentRecord();
		return dao.getstudentRecord();
	}
	public String insertStudent(Student stud) {
		String msg=dao.insertStudent(stud);
		return msg;
	}
	
	public String updateStudent(Student stud) {
		String msg=dao.updateStudent(stud);
		return msg;
	}
	public String deletestudentbyid(int id) {
		String msg=dao.deletestudentbyid(id);
		return msg;
	}

	
	
	
}
